import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class VirtualKeyboardApp extends JFrame implements ActionListener {

    private JTextArea textArea;
    private JButton[] buttons;

    public VirtualKeyboardApp() {
        setTitle("Teclado Virtual");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        textArea = new JTextArea(5, 20);
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.NORTH);

        buttons = new JButton[26];
        JPanel keyboardPanel = new JPanel(new GridLayout(2, 13));

        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton(String.valueOf((char) ('A' + i)));
            buttons[i].addActionListener(this);
            keyboardPanel.add(buttons[i]);
        }

        add(keyboardPanel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);

        textArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                char keyPressed = e.getKeyChar();
                if (Character.isLetter(keyPressed)) {
                    char upperCaseKey = Character.toUpperCase(keyPressed);
                    highlightButton(upperCaseKey);
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton clickedButton = (JButton) e.getSource();
        String buttonText = clickedButton.getText();
        textArea.append(buttonText);

        char keyChar = buttonText.charAt(0);
        highlightButton(keyChar);
    }

    private void highlightButton(char keyChar) {
        for (JButton button : buttons) {
            char buttonChar = button.getText().charAt(0);
            if (buttonChar == keyChar) {
                button.setBackground(Color.YELLOW);
            } else {
                button.setBackground(UIManager.getColor("Button.background"));
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VirtualKeyboardApp().setVisible(true);
            }
        });
    }
}
